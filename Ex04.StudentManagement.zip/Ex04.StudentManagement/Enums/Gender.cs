namespace Ex04.StudentManagement.Enums;

/// <summary>
/// Giới tính của sinh viên.
/// </summary>
public enum Gender
{
    Nam,
    Nu,
    Khac
}
