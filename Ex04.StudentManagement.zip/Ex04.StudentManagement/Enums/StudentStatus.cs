namespace Ex04.StudentManagement.Enums;

/// <summary>
/// Trạng thái học tập của sinh viên.
/// </summary>
public enum StudentStatus
{
    DangHoc,        // Đang học
    BaoLuu,         // Bảo lưu
    DaTotNghiep,    // Đã tốt nghiệp
    ThoiHoc         // Thôi học
}
